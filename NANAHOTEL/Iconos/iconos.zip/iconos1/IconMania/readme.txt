Thank you for downloading !conMania

Please enjoy all the icons and cursors!

http://iconmania.8m.com

!!!

!conMania's goal is to have 2001 icons by the year 2001!
Submit as many original icons as you can!

!!!

Have fun!

Steve P.
stevep@iocc.com