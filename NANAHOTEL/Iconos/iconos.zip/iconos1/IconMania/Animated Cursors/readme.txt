=======================================================================
 ICONStructions� System Cursors Version 1.2
=======================================================================

 Copyright� 1998 ICONStructions�
 ICONS & DESKTOP ENHANCEMENTS

 http://www.iconstructions.com
 E-mail: icons@blably.com

 a division of Blably.com� Inc.
 http://www.blably.com


 This file can be distributed only in the original archive.
 Do not change this file or any files within.
 If this file is to be copied to another site, distribuited on CD-ROMs
 or in any other way, please contact the developer.

 All trademarks are owned by the respective company.

=======================================================================
